/** Automatically generated file. DO NOT MODIFY */
package com.example.myuserform;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}